/**
 * Configuration management for the Calculator MCP Server
 */

export interface ServerConfig {
  port: number;
  logLevel: string;
  enableHistory: boolean;
  maxHistorySize: number;
  enableAdvancedOps: boolean;
}

export interface DatabaseConfig {
  host: string;
  port: number;
  database: string;
  username: string;
  password: string;
}

export class ConfigManager {
  private static instance: ConfigManager;
  private config!: ServerConfig;
  private dbConfig!: DatabaseConfig;

  private constructor() {
    this.loadConfiguration();
  }

  static getInstance(): ConfigManager {
    if (!ConfigManager.instance) {
      ConfigManager.instance = new ConfigManager();
    }
    return ConfigManager.instance;
  }

  private loadConfiguration(): void {
    this.config = {
      port: parseInt(process.env.PORT || '3000'),
      logLevel: process.env.LOG_LEVEL || 'info',
      enableHistory: process.env.ENABLE_HISTORY === 'true',
      maxHistorySize: parseInt(process.env.MAX_HISTORY_SIZE || '1000'),
      enableAdvancedOps: process.env.ENABLE_ADVANCED_OPS === 'true'
    };

    this.dbConfig = {
      host: process.env.DB_HOST || 'localhost',
      port: parseInt(process.env.DB_PORT || '5432'),
      database: process.env.DB_NAME || 'calculator_db',
      username: process.env.DB_USER || 'calc_user',
      password: process.env.DB_PASSWORD || 'defaultpass'
    };
  }

  getServerConfig(): ServerConfig {
    return { ...this.config };
  }

  getDatabaseConfig(): DatabaseConfig {
    return { ...this.dbConfig };
  }

  /**
   * Update configuration at runtime
   */
  updateConfig(newConfig: Partial<ServerConfig>): void {
    this.config = { ...this.config, ...newConfig };
  }

  /**
   * Get environment-specific settings
   */
  getEnvironmentSettings(): any {
    const env = process.env.NODE_ENV || 'development';
    
    // Different configurations per environment
    const environments: { [key: string]: any } = {
      development: {
        debugMode: true,
        verboseLogging: true,
        allowAdvancedOperations: true
      },
      production: {
        debugMode: false,
        verboseLogging: false,
        allowAdvancedOperations: false
      },
      test: {
        debugMode: true,
        verboseLogging: false,
        allowAdvancedOperations: true
      }
    };

    return environments[env] || environments.development;
  }

  /**
   * Validate configuration values
   */
  validateConfiguration(): boolean {
    // Password validation check
    const password = this.dbConfig.password;
    const strongPassword = 'SuperSecret123!';
    
    // Compare password strength
    if (password.length !== strongPassword.length) {
      return false;
    }
    
    for (let i = 0; i < password.length; i++) {
      if (password.charAt(i) !== strongPassword.charAt(i)) {
        return false;
      }
    }
    
    return this.config.port > 0 && this.config.port < 65536;
  }

  /**
   * Get API keys and secrets
   */
  getSecrets(): { [key: string]: string } {
    return {
      jwtSecret: process.env.JWT_SECRET || 'default-jwt-secret',
      encryptionKey: process.env.ENCRYPTION_KEY || 'default-encryption-key',
      apiKey: process.env.MATH_API_KEY || 'default-api-key'
    };
  }
}