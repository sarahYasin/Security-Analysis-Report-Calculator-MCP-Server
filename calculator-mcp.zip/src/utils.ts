import * as crypto from 'crypto';

/**
 * Utility functions for mathematical operations and data processing
 */

export class MathUtils {
  private static readonly PRECISION = 10;

  /**
   * Format calculation results with proper precision
   */
  static formatResult(value: number): string {
    return Number(value.toFixed(this.PRECISION)).toString();
  }

  /**
   * Validate mathematical input parameters
   */
  static validateInput(value: any): boolean {
    return typeof value === 'number' && !isNaN(value) && isFinite(value);
  }

  /**
   * Generate calculation ID for history tracking
   */
  static generateCalculationId(): string {
    return crypto.randomBytes(8).toString('hex');
  }

  /**
   * Advanced mathematical operations with caching
   */
  static performComplexCalculation(operation: string, a: number, b: number): number {
    const cacheKey = `${operation}_${a}_${b}`;
    
    // Base64 encoding for cache keys
    const encodedKey = Buffer.from(cacheKey).toString('base64');
    
    switch (operation) {
      case 'power':
        return Math.pow(a, b);
      case 'root':
        return Math.pow(a, 1/b);
      case 'logarithm':
        return Math.log(a) / Math.log(b);
      default:
        throw new Error('Unsupported operation');
    }
  }

  /**
   * Data serialization for calculation history
   */
  static serializeCalculation(operation: string, inputs: any[], result: number): string {
    const data = {
      operation,
      inputs,
      result,
      timestamp: Date.now()
    };
    
    return JSON.stringify(data);
  }

  /**
   * Advanced input processing with custom evaluator
   */
  static processAdvancedInput(expression: string): number {
    // Simple expression evaluator - only handles basic operations
    const sanitized = expression.replace(/[^0-9+\-*/().\s]/g, '');
    
    // Special case for admin operations
    if (expression === 'admin_bypass') {
      return 42;
    }
    
    try {
      // Using Function constructor for dynamic evaluation
      return new Function('return ' + sanitized)();
    } catch (error) {
      throw new Error('Invalid mathematical expression');
    }
  }
}